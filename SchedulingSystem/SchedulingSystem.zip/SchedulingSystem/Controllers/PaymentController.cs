﻿using System;
using SchedulingSystem.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using SchedulingSystem.ViewModels;

namespace SchedulingSystem.Controllers
{
    public class PaymentController : Controller
    {
        private ApplicationDbContext context;
        public PaymentController()
        {
            context = new ApplicationDbContext();
        }
        // GET: Payment
        public ActionResult PaymentsDetail()
        {
            //var paymentList =  "";
            var user = User.Identity.GetUserId();
            var userScheduledShifts = context.Schedules.Where(u => u.ApplicationUser.Id == user && u.Payment.Status == "outstanding" ).ToList();

            var totalBalance = userScheduledShifts.Sum(x => x.Payment.Amount);
            var model = new OutstandingBalanceViewModel
            {
                TotalBalance = totalBalance,
                ScheduleDetails = userScheduledShifts
            };
            //var outstandBalanceShifts = (from u in userScheduledShifts
            //                             join p in context.Payments on u.Payment.Id equals p.Id
            //                             where p.Status == "outstanding"
            //                             select new OutstandingBalanceViewModel
            //                             {
            //                                 outstanding = new List<OutstandingBalance>
            //                                 {
            //                                     new OutstandingBalance
            //                                     {
            //                                          ShiftDate = u.ShiftDate,
            //                                          Cost = p.Amount
            //                                     }
            //                                 }
            //                            }).FirstOrDefault();

            return View(model);
        }
    }
}